#include "Legolas.h"

Legolas::Legolas(Vec2d pos, int hp, int atk, Vec2d spd, Vec2d vel)
    :Character(pos, hp, atk, spd, vel)
{};

Legolas::~Legolas(){};
SDL_Rect Legolas::getBounds() const{};

void Legolas::draw(SDLWindow& window) {};

void Legolas::loadAssets(SDLWindow& window){
    bowTexture=window.readFile("assets/bowSprite.png");
}

void Legolas::limitMovement(){
    if(position.x<=leftBound)
        velocity.x+=1;
    if(position.x>=rightBound)
        velocity.x-=1;
}

void Legolas::update() {
    limitMovement();
    move();
};


void Legolas::drawBody(SDLWindow& window){
    int x = (int)position.x;
    int y = (int)position.y;

    // COLORS
    SDLColor skin(255, 220, 150, 255);      // light skin
    SDLColor hair(240, 220, 40, 255);       // blond
    SDLColor tunic(200, 200, 255, 255);     // white-blue
    SDLColor trim(80, 120, 255, 255);       // blue accents
    SDLColor eyes(0, 0, 0, 255);

    // HEAD
    window.setColor(skin);
    window.drawFilledRect(x + 2, y - 12, 16, 12);

    // HAIR (blond)
    window.setColor(hair);
    window.drawFilledRect(x + 2,  y - 16, 16, 6);   // top hair
    window.drawFilledRect(x + 1,  y - 12, 3, 12);   // left side
    window.drawFilledRect(x + 16, y - 12, 3, 12);   // right side

    // EYES
    window.setColor(eyes);
    window.drawFilledRect(x + 6,  y - 9, 3, 3);
    window.drawFilledRect(x + 11, y - 9, 3, 3);

    // TUNIC (white/blue)
    window.setColor(tunic);
    window.drawFilledRect(x, y, 20, 20);

    // BLUE TRIM
    window.setColor(trim);
    window.drawFilledRect(x, y + 18, 20, 4);

    // LOWER ROBE / LEGS
    window.setColor(tunic);
    window.drawFilledRect(x, y + 20, 20, 12);

    // ARMS (skin)
    window.setColor(skin);
    window.drawFilledRect(x - 6,  y + 4, 6, 16);   // left arm
    window.drawFilledRect(x + 20, y + 4, 6, 16);   // right arm

    // LEGS (blue)
    window.setColor(trim);
    window.drawFilledRect(x + 2,  y + 28, 6, 14);
    window.drawFilledRect(x + 12, y + 28, 6, 14);
}
void Legolas::drawBow(SDLWindow& window, int mouseX, int mouseY)
{
    if (!bowTexture){
        //std::cout<<"bowSprite.png falhou ao carregar..."<<std::endl;
        return;
    }


    // 1. Direção para o rato
    float dx = mouseX - position.x;
    float dy = mouseY - position.y;
    float angleRad = atan2(dy, dx);
    float angleDeg = angleRad * (180.0f / M_PI);

    // 2. Offset do arco relativo ao corpo
    int bowX = (int)position.x-10;   // ajusta conforme necessário
    int bowY = (int)position.y-6;

    // 3. Desenhar sprite rotacionado
    window.renderTexture(bowTexture, bowX, bowY, 255, angleDeg);
}

void Legolas::draw(SDLWindow& window, int mouseX, int mouseY) {
    drawBody(window);
    drawBow(window, mouseX, mouseY);
}



