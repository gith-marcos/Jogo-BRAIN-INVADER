#include "DrawText.h"

void drawText(SDLWindow &win, const std::string &text, int x, int y, int scale, SDLColor color)
{
    win.setColor(color);

    int cursorX = x;
    int cursorY = y;

    for (char c : text)
    {
        // Handle space
        if (c == ' ') {
            cursorX += 6 * scale;
            continue;
        }

        // Convert lowercase → uppercase
        if (c >= 'a' && c <= 'z')
            c -= 32;

        int index = -1;

        // A–Z → indices 0–25
        if (c >= 'A' && c <= 'Z')
            index = c - 'A';

        // 0–9 → indices 26–35
        else if (c >= '0' && c <= '9')
            index = (c - '0') + 26;

        // Unsupported character → skip
        if (index < 0)
            continue;

        // Draw the 5×7 bitmap
        for (int row = 0; row < 7; row++)
        {
            uint8_t rowBits = FONT5x7[index][row];
            for (int col = 0; col < 5; col++)
                if (rowBits & (1 << (4 - col)))
                    win.drawFilledRect(cursorX + col * scale,
                                       cursorY + row * scale,
                                       scale,
                                       scale);

        }

        cursorX += 6 * scale; // advance cursor
    }
}
