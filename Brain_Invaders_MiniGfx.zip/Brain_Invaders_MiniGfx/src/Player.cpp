#include "Player.h"

#define VIDA 100

Player::Player(Vec2d posicao, Vec2d velocidade, Vec2d direcao)
    : GameObject(posicao, velocidade, direcao)
{
    vida = VIDA;
    limitesObjeto = {posicao.x - 95, posicao.y - 150, 95, 150};
}

Player::~Player(){};

void Player::move(){
    if(direcaoMovimento==-1){
        direcao.x= -1;
        direcao.y= 0;
    }
    else if(direcaoMovimento==1){
        direcao.x= 1;
        direcao.y= 0;
    }
    else if(direcaoMovimento==0)
        return;


    posicao.x += velocidade.x * direcao.x;
    posicao.y += velocidade.y * direcao.y;
}

void Player::collision(int dano){
    receberDano(dano);
}

void Player::update(){
    if(this->getVida()<=0)
        this->setVivo(false);
    limitesObjeto.x = posicao.x-95;
    limitesObjeto.y = posicao.y-95;
    move();
}

void Player::draw(SDLWindow& window){
    if(direcaoMovimento==0)
        naveTex = window.readFile("assets/Foguetao.png");
    else if(direcaoMovimento==1)
        naveTex = window.readFile("assets/Foguetao_E.png");
    else if(direcaoMovimento==-1)
        naveTex = window.readFile("assets/Foguetao_D.png");

    window.renderTexture(naveTex, this->posicao.x-47, this->posicao.y-75, 255, 0);
}

