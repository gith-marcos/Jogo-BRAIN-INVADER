#include "Enemy.h"



Enemy::Enemy(Vec2d posicao, Vec2d velocidade, Vec2d direcao)
    : GameObject(posicao, velocidade, direcao)
{
    vida = VIDA;
    limitesObjeto = {posicao.x, posicao.y, 50, 50};
}

Enemy::~Enemy(){};

void Enemy::move(){
    posicao.x += velocidade.x * direcao.x;
    posicao.y += velocidade.y * direcao.y;
}

void Enemy::collision(int dano){
    receberDano(dano);
}

void Enemy::update(){
    if(getVelocidadeDisparo()!=0){
        this->setPodeDisparar(false);
        this->setVelocidadeDisparo(getVelocidadeDisparo()-1);
    }
    else if(getVelocidadeDisparo()==0){
        this->setPodeDisparar(true);
    }

    if(this->getVida()<=20 && this->getVida()>10){
        this->setEstado(1);
        this->setVelocidade(Vec2d(-3,0));
    }
    else if(this->getVida()<=10){
        this->setEstado(2);
        this->setVelocidade(Vec2d(0,0));
    }

    if(this->getVida()<=0){
        this->setVivo(false);
    }

    limitesObjeto.x = posicao.x;
    limitesObjeto.y = posicao.y;
    move();
}

void Enemy::draw(SDLWindow& window){
    if(estado==0){
        cerebroTex = window.readFile("assets/Cerebro_base.png");
    }
    else if(estado==1){
        cerebroTex = window.readFile("assets/Cerebro_fogo.png");
    }
    else if(estado==2){
        cerebroTex = window.readFile("assets/Cerebro_congelado.png");
    }

    window.renderTexture(cerebroTex, this->posicao.x-47, this->posicao.y-75, 255, 0);
}
