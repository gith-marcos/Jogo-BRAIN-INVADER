#include "Projectile.h"

Projectile::Projectile(Vec2d posicao, Vec2d velocidade, Vec2d direcao, int ataque, int versao)
            : GameObject(posicao, velocidade, direcao)
{
    setVersao(versao);
    setAtaque(ataque);
    limitesObjeto = {posicao.x, posicao.y, 50, 26};
}
Projectile::~Projectile(){};

void Projectile::update() {
    limitesObjeto.x = posicao.x;
    limitesObjeto.y = posicao.y;
    move();
};
void Projectile::move(){
    posicao.x += velocidade.x * direcao.x;
    posicao.y += velocidade.y * direcao.y;
};
void Projectile::draw(SDLWindow& window) {
    if(versao==1){
        drawBalaJogador(window);
    }
    else if(this->versao==2){
        balaTex = window.readFile("assets/Bala_Enimigo_verde.png");
        window.renderTexture(balaTex, this->posicao.x-47, this->posicao.y-75, 255, 0);
    }
    else if(this->versao==3){
        balaTex = window.readFile("assets/Bala_Enimigo_vermelho.png");
        window.renderTexture(balaTex, this->posicao.x-47, this->posicao.y-75, 255, 0);
    }

};

void Projectile::drawBalaJogador(SDLWindow& window){
    balaTex = window.readFile("assets/Bala_Jogador.png");
    window.renderTexture(balaTex, this->posicao.x-47, this->posicao.y-75, 255, 0);
}

void Projectile::drawBalaEnimigo(SDLWindow& window){
    if(this->versao==2){
        balaTex = window.readFile("assets/Bala_Enimigo_verde.png");
    }
    else if(this->versao==3){
        balaTex = window.readFile("assets/Bala_Enimigo_vermelho.png");
    }
    window.renderTexture(balaTex, this->posicao.x-47, this->posicao.y-75, 255, 0);
}
