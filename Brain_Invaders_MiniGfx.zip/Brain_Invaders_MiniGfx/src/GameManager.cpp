#include "GameManager.h"

GameManager::GameManager()
    : enemySpawnPos(800, 550),
      legolasSpawnPos(150, 310),
      castlePos(100, 500),
      legolas(legolasSpawnPos, 10, 5, Vec2d(0.7,1), Vec2d(0,0)),
      castle(castlePos, 100)
{};

GameManager::~GameManager(){};

void GameManager::loadAssets(SDLWindow& window){
    arrowTex=window.readFile("assets/arrowSprite.png");
    legolas.loadAssets(window);
}

bool GameManager::checkForCollision(const GameObject& a, const GameObject& b) const {
    SDL_Rect A = a.getBounds();
    SDL_Rect B = b.getBounds();

    return (A.x < B.x + B.w &&
            A.x + A.w > B.x &&
            A.y < B.y + B.h &&
            A.y + A.h > B.y);
}


void GameManager::updateObjects(){
    legolas.update();

    for (Enemy& enemy : enemies)
        if(enemy.isActive())
            enemy.update();

    for (Arrow& arrow : arrows)
        if(arrow.isActive())
            arrow.update();

    objectsCollision();
    gameEnd();
};


bool GameManager::isWaveEnd() const{
    for (const Enemy& e : enemies) {
        if (e.isActive())
            return false;
    }
    return true;
}

void GameManager::spawnWave(){
    currentWave++;
    std::cout<<"Wave: "<<currentWave<<std::endl;
    enemyCount = baseEnemyCount+currentWave;
    for (int i=0; i<enemyCount; i++){
        enemies.push_back(Enemy(
            enemySpawnPos,            // position
            50,                         // HP
            10,                         // attack
            5,                          // reward
            Vec2d(randomFloat(0.255, 0.455), 1.0),  // speed
            Vec2d(-1, 0.0)              // velocity
        ));
        enemies.back().turnOnOff(true);
    }
}

void GameManager::drawObjects(SDLWindow& window, int mouseX, int mouseY){
    //*********  LEGOLAS **********//
    legolas.changeVel(0);
    if (window.keyDown(SDLKey::A))
        legolas.changeVel(-0.8);

    if (window.keyDown(SDLKey::D))
        legolas.changeVel(+0.8);
    legolas.draw(window, mouseX, mouseY);

    //*********  ARROWS **********//

    if(window.keyDown(SDLKey::SPACE) && arrowDelay==0){
        spawnArrow(mouseX, mouseY);
        arrowDelay+=FIRE_RATE;
    }
    if(arrowDelay>0)
        arrowDelay--;

    for(Arrow& arrow : arrows)
        if(arrow.isActive())
            arrow.draw(window, arrowTex);


    //*********  ENEMIES **********//
    for(Enemy& enemy : enemies)
        if(enemy.isActive())
            enemy.draw(window);

    castle.drawHpBar(window);

    SDLColor textColor = SDLColor(255, 255, 255, 255);
    drawText(window, "Wave "+std::to_string(this->currentWave), 325, 17, 4, textColor);
}

void GameManager::pushBack(Character& character, int amount){
    character.changeVel(amount);
}

void GameManager::objectsCollision(){
    for(Arrow& arrow : arrows)
        for(Enemy& enemy : enemies)
            if(checkForCollision(arrow, enemy)
            && arrow.dealDamageState()
            && enemy.isActive()){
                enemy.takeDamage(arrow.getDamage());
                pushBack(enemy, 5);
                arrow.turnOnOff(false);
                arrow.setDealDamage(false);
            }


    for (Enemy& enemy : enemies){
        int pushBackAmount = randomInt(10,25);

        if(checkForCollision(castle, enemy) && enemy.isActive()){
            castle.takeDamage(enemy.getDamage());
            gameEnd();
            pushBack(enemy, pushBackAmount);
        }
    }

}

bool GameManager::isGameEnd(){
    return gameOver;
}

void GameManager::gameEnd(){
    if(castle.getHP()<=0){
        std::cout<<"Game Over!"<<std::endl;
        gameOver=true;
    }
}

void GameManager::spawnArrow(int mouseX, int mouseY){
    float bowX = legolas.getPosition().x - 10;
    float bowY = legolas.getPosition().y - 6;

    Vec2d bowPos(bowX, bowY);

    // Direction vector
    Vec2d dir(mouseX - bowPos.x, mouseY - bowPos.y);
    // Create arrow with normalized velocity
    Arrow arrow(bowPos, 10, dir);

    arrow.turnOnOff(true);
    arrows.push_back(arrow);

}

void gameStart(){}
