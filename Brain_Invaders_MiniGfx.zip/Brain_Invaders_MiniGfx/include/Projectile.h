#pragma once
#include "GameObject.h"

class Projectile : public GameObject{
    private:
        int versao=0;// 1 - Bala jogador, 2 - Bala enimigo(Normal), 3 - Bala enimigo(Fogo)
        Texture balaTex;

    public:
        Projectile(Vec2d posicao, Vec2d velocidade, Vec2d direcao, int ataque, int versao);
        ~Projectile();

        void move() override;
        void update() override;
        void draw(SDLWindow& window) override;
        void drawBalaJogador(SDLWindow& window);
        void drawBalaEnimigo(SDLWindow& window);

        void setVersao(int versaoNova) {versao=versaoNova;}
};
