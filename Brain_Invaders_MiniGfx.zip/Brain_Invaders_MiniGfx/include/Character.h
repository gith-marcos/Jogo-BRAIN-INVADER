#ifndef CHARACTER_H
#define CHARACTER_H

#include "GameObject.h"
#include "Vec2D.h"

class Character : public GameObject {
    protected:
        int hitPoints=0;
        int attackPower=0;
        Vec2d velocity={0,0};
        Vec2d speed={0,0};

    public:
        //Character();
        Character(Vec2d pos, int hp, int atk, Vec2d spd, Vec2d vel);
        virtual ~Character();

        int getDamage();
        void takeDamage(int dmg);
        int getHP() const;
        bool isActive() const;
        void changeVel(float amount);

        void move();
};

#endif // CHARACTER_H

