#ifndef GAME_MANAGER_H
#define GAME_MANAGER_H

#include "Legolas.h"
#include "Enemy.h"
#include "Castle.h"
#include "Arrow.h"
#include "RandomFunc.h"
#include "DrawText.h"

#define FIRE_RATE 30



class GameManager{
    private:
        Vec2d enemySpawnPos;
        Vec2d legolasSpawnPos;
        Vec2d castlePos;
        Texture arrowTex=nullptr;
        int arrowDelay=0;

        Legolas legolas;
        Castle castle;

        std::vector<Enemy> enemies;
        std::vector<Arrow> arrows;

        int currentWave=0;
        int baseEnemyCount=2;
        int enemyCount;
        bool gameOver=false;

    public:
        GameManager();
        ~GameManager();
        void updateObjects();
        void gameStart();
        void gameEnd();
        bool isGameEnd();
        bool checkForCollision(const GameObject& a, const GameObject& b) const;
        bool isWaveEnd() const;
        void spawnWave();
        void drawObjects(SDLWindow& window, int mouseX, int mouseY);
        void pushBack(Character& character, int amount);
        void objectsCollision();
        void loadAssets(SDLWindow& window);
        void spawnArrow(int mouseX, int mouseY);
};


#endif // GAME_MANAGER_H
