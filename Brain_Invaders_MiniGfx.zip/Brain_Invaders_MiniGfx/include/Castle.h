#ifndef CASTLE_H
#define CASTLE_H

#include "Character.h"
#include "Vec2D.h"

class Castle : public Character{
    public:
        SDL_Rect getBounds() const override;

        Castle(Vec2d pos, int hp);
        ~Castle();
        void draw(SDLWindow& window) override {};
        void drawHpBar(SDLWindow& window);
        void update() override {};
};

#endif // CASTLE_H
