#pragma once
#include "MiniGfx.h"

// ESTRUTURA VEC2D //
struct Vec2d  {
    int x;
    int y;

    Vec2d() : x(0), y(0){}
    Vec2d(float x, float y) : x(x), y(y) {}
};

// CLASSE MÃE //
class GameObject{

    // ATRIBUTOS //
     protected:
        Vec2d posicao;
        Vec2d velocidade;
        Vec2d direcao;
        SDL_Rect limitesObjeto;

        int vida;
        int ataque;

        bool vivo;

    // METODOS //
     public:
        GameObject(Vec2d posicao, Vec2d velocidade, Vec2d direcao)
            : posicao(posicao), velocidade(velocidade), direcao(direcao)
        {}
        ~GameObject(){};

        virtual void update()=0;
        virtual void draw(SDLWindow& window)=0;
        virtual void move()=0;
        void receberDano(int dano) {
            vida-=dano;
            if(vida <= 0)
                vivo = false;
        };

        int getVida() {return vida;}
        int getAtaque() {return ataque;}
        SDL_Rect getLimites() {return limitesObjeto;}
        Vec2d getPosicao() {return posicao;}
        bool getVivo() {return vivo;}

        void setVivo(bool estaVivo) {vivo=estaVivo;}
        void setVida(int novaVida) {vida=novaVida;}
        void setDirecao(Vec2d direcaoNova) {direcao=direcaoNova;}
        void setPosicao(Vec2d posicaoNova) {posicao=posicaoNova;}
        void setAtaque(int valorAtaque) {ataque=valorAtaque;}
        void setVelocidade(Vec2d novaVelocidade) {velocidade=novaVelocidade;}

};


