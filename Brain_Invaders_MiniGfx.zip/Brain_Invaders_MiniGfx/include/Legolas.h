#ifndef LEGOLAS_H
#define LEGOLAS_H

#include "Vec2D.h"
#include "Character.h"
// LeftBound = 85, 325
// RightBound = 185, 325

class Legolas : public Character {
    private:
        static Legolas* legolas;
        Texture bowTexture = nullptr;
        float leftBound=85;
        float rightBound=185;

    public:
        Legolas(Vec2d pos, int hp, int atk, Vec2d spd, Vec2d vel);
        ~Legolas();

        static Legolas &getLegolas(Vec2d pos);
        void update() override;
        void draw(SDLWindow& window) override;
        void draw(SDLWindow& window, int mouseX, int mouseY) ;
        void drawBody(SDLWindow& window);
        void drawBow(SDLWindow& window, int mouseX, int mouseY);
        void loadAssets(SDLWindow& window);
        void limitMovement();
        SDL_Rect getBounds() const override;
};


#endif // LEGOLAS_H

