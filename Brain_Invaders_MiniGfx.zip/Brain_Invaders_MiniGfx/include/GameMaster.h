#pragma once
#include "Player.h"
#include "Enemy.h"
#include "Projectile.h"

#define N_ENIMIGOS 15
#define VEL_DISPARO_ENIMIGO 2000



class GameMaster {
    public:
        SDL_Rect limitesMapa;

        Vec2d posInicialEnimigos;
        Vec2d posAtualEnimigos;
        std::vector<Enemy> enimigos;
        std::vector<Projectile> balasJog;
        std::vector<Projectile> balasEni;

        Player foguetao;
        Projectile balaJogador;
        Projectile copiaBala;

        GameMaster(SDL_Rect limitesM)
            : limitesMapa(limitesM),
              foguetao(Vec2d(300, 700), Vec2d(5, 0.0), Vec2d(0.0, 0.0)),
              balaJogador(Vec2d(foguetao.getPosicao().x, foguetao.getPosicao().y), Vec2d(0,2), Vec2d(0,-2), 10, 1),
              copiaBala(Vec2d(0,0), Vec2d(0, 0), Vec2d(0, 0), 10, 1)
        {
            posInicialEnimigos.x = 550;
            posInicialEnimigos.y = 100;
            posAtualEnimigos.x = posInicialEnimigos.x;
        }


        void updateObjects() {

            // 1. Tratar colisões (com base nas posições do frame anterior)
            for (Projectile& a : balasJog) {
                for (Enemy& b : enimigos) {
                    if (a.getVivo() && b.getVivo()) {
                        if (verificarCollisao(a, b)) {
                            b.collision(a.getAtaque());
                            a.setVivo(false);
                        }
                    }
                }
            }

            for (Projectile& bala : balasEni) {
                    if (foguetao.getVivo() && bala.getVivo()) {
                        if (verificarCollisao(foguetao, bala)) {
                            foguetao.collision(bala.getAtaque());
                            std::cout<<foguetao.getVida()<<std::endl;
                            bala.setVivo(false);
                    }
                }
            }


            // 2. Atualizar movimento do jogador
            int limiteFogX = foguetao.getLimites().x + foguetao.getLimites().w;
            if (limiteFogX >= limitesMapa.w - 10)
                foguetao.mudarDirecao(-1);
            else if (limiteFogX <= 10)
                foguetao.mudarDirecao(1);

            foguetao.update();

            // 3. Atualizar inimigos (movimento + contagem decrescente do cooldown)
            for (Enemy& c : enimigos) {
                if (!c.getVivo()) continue;

                // Lógica de movimento dos inimigos
                if (c.getLimites().x <= 30) {
                    c.setDirecao(Vec2d(-1, 0));
                }
                else if (c.getLimites().x >= limitesMapa.w - 20) {
                    c.setDirecao(Vec2d(1, 0));
                    c.setPosicao(Vec2d(c.getPosicao().x, c.getPosicao().y + 20));
                }

                // Atualizar inimigo (aqui o cooldown é decrementado)
                c.update();

                // 4. Tratar o disparo do inimigo APÓS o update()
                if (c.getPodeDisparar()) {
                    int randVel = (rand() % VEL_DISPARO_ENIMIGO) + 1; // nunca 0

                    if(c.getEstado()==0){
                        c.setVelocidadeDisparo(randVel);
                    }
                    else if (c.getEstado()==1){
                        c.setVelocidadeDisparo(100);
                    }
                    else if (c.getEstado()==2){
                        c.setPodeDisparar(false);
                    }



                    if(c.getPodeDisparar()){
                        dispararEnimigo(c);
                        c.setPodeDisparar(false);
                    }

                }
            }

            // 5. Atualizar todas as balas (jogador + inimigos)
            for (Projectile& bala : balasJog)
                if (bala.getVivo())
                    bala.update();

            for (Projectile& bala : balasEni)
                if (bala.getVivo())
                    bala.update();
        }


        void chamarEnimigos(){
            int fila1 = posInicialEnimigos.y;
            int fila2 = posInicialEnimigos.y+70;
            int y_pos;
            int i = 0;

            if(i < N_ENIMIGOS/2){
                y_pos=fila1;
                for(i; i<N_ENIMIGOS/2; i++){
                    int randVel = rand() % VEL_DISPARO_ENIMIGO;
                    enimigos.push_back(Enemy(
                                             Vec2d(posAtualEnimigos.x, y_pos),
                                             Vec2d(-1, 0),
                                             Vec2d(1, 0)
                                            ));
                    enimigos.back().setEstado(0);
                    enimigos.back().setVelocidadeDisparo(randVel);
                    enimigos.back().setVivo(true);
                    posAtualEnimigos.x-=70;
                }
            }
            if(i >= (N_ENIMIGOS/2)-1){
                posAtualEnimigos.x=posInicialEnimigos.x;
                y_pos=fila2;
                i=0;
                for(i; i<N_ENIMIGOS/2; i++){
                    int randVel = rand() % VEL_DISPARO_ENIMIGO;
                    enimigos.push_back(Enemy(
                                             Vec2d(posAtualEnimigos.x, y_pos),
                                             Vec2d(-1, 0),
                                             Vec2d(1, 0)
                                            ));
                    enimigos.back().setEstado(0);
                    enimigos.back().setVelocidadeDisparo(randVel);
                    enimigos.back().setVivo(true);
                    posAtualEnimigos.x-=70;
                }
            }
        }

        void dispararJogador(){
            Projectile novaBala = balaJogador;
            novaBala.setPosicao(Vec2d(foguetao.getPosicao().x+32, foguetao.getPosicao().y));
            novaBala.setVivo(true);
            balasJog.push_back(novaBala);
        }

        void dispararEnimigo(Enemy& enimigo){
            if(enimigo.getEstado()==0){
                copiaBala = Projectile(Vec2d(enimigo.getPosicao().x, enimigo.getPosicao().y), Vec2d(0,-1), Vec2d(0,-2), 10, 2);
            }
            else if(enimigo.getEstado()==1){
                copiaBala = Projectile(Vec2d(enimigo.getPosicao().x, enimigo.getPosicao().y), Vec2d(0,-1), Vec2d(0,-2), 10, 3);
            }
            copiaBala.setPosicao(Vec2d(enimigo.getPosicao().x, enimigo.getPosicao().y));
            copiaBala.setVivo(true);
            balasEni.push_back(copiaBala);
        }

        void drawObjects(SDLWindow& window){
            foguetao.draw(window);

            for(Enemy& cerebro : enimigos){
                if(cerebro.getVivo()){
                    cerebro.draw(window);
                }
            }

            for(Projectile& bala : balasJog){
                if(bala.getVivo()){
                    bala.draw(window);
                }
            }

            for(Projectile& bala : balasEni){
                if(bala.getVivo()){
                    bala.draw(window);
                }
            }
        }

        bool verificarCollisao(GameObject& a, GameObject& b) {
            SDL_Rect limitesA = a.getLimites();
            SDL_Rect limitesB = b.getLimites();

            // Update rects to actual positions
            limitesA.x = static_cast<int>(a.getPosicao().x);
            limitesA.y = static_cast<int>(a.getPosicao().y);
            limitesB.x = static_cast<int>(b.getPosicao().x);
            limitesB.y = static_cast<int>(b.getPosicao().y);

            // AABB collision check
            bool colide = limitesA.x < limitesB.x + limitesB.w &&
                          limitesA.x + limitesA.w > limitesB.x &&
                          limitesA.y < limitesB.y + limitesB.h &&
                          limitesA.y + limitesA.h > limitesB.y;

            return colide;
        }


};
