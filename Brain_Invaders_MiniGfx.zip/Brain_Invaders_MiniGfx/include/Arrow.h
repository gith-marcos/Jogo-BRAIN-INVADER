#ifndef ARROW_H
#define ARROW_H

#include "Character.h"

class Arrow : public Character{
    private:
        Texture arrowTexture=nullptr;
        bool canDealDamage=true;

    public:
        Arrow(Vec2d pos, int atk, Vec2d vel);
        ~Arrow();
        void update() override;
        void draw(SDLWindow& window) override;
        SDL_Rect getBounds() const override;
        void draw(SDLWindow& window, Texture arrowTexture);
        bool dealDamageState() {return canDealDamage;}
        void setDealDamage(bool isAllowed) {canDealDamage=isAllowed;}

};

#endif // ARROW_H

