#include "GameObject.h"

#define VIDA 30


class Enemy : public GameObject {
    private:
        Texture cerebroTex;

        int estado; // 0 - Normal, 1 - Irritado(Fogo), 2 - Congelado
        int velocidadeDisparo;
        bool podeDisparar;

        void move() override;

    public:
        Enemy(Vec2d pos, Vec2d velocidade, Vec2d direcao);
        ~Enemy();

        void update() override;
        void draw(SDLWindow& window) override;
        void collision(int dano);

        int getEstado() {return estado;}
        int getVelocidadeDisparo() {return velocidadeDisparo;}
        bool getPodeDisparar() {return podeDisparar;}

        void setEstado(int novoEstado) {estado=novoEstado;}
        void setVelocidadeDisparo(int novoDisparo) {velocidadeDisparo=novoDisparo;}
        void setPodeDisparar(bool disparar) {podeDisparar=disparar;}
};
