#include "GameObject.h"

class Player : public GameObject {
    private:
        int direcaoMovimento; // -1 ESQUERDA    0 PARADO     1 DIREITA
        Texture naveTex;

        void move() override;


    public:
        Player(Vec2d pos, Vec2d velocidade, Vec2d direcao);
        ~Player();

        void collision(int dano);
        void update() override;
        void draw(SDLWindow& window) override;
        void mudarDirecao(int direcao) {direcaoMovimento=direcao;} // -1 ESQUERDA    0 PARADO     1 DIREITA


};
