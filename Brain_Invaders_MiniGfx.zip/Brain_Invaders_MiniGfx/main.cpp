#include <vector>
#include <cstdlib>
#include <ctime>
#include "MiniGfx.h"
#include <random>

#include "GameMaster.h"

int main(){
    int windowWidth=600;
    int windowHeight=800;
	// Colors...
	SDLColor backColor(0,0,0,255);
	SDLColor foreColor(255,255,255,255);

    //Player foguetao(Vec2d(300, 700), {5, 0.0}, {0.0, 0.0});
    SDL_Rect limitesJanela = {0, 0, windowWidth, windowHeight};
    GameMaster master(limitesJanela);

    Texture imgFundo;
    master.chamarEnimigos();

	// Window...
	std::string windowTitle="Brain Invaders";
	SDLWindow window(windowWidth,windowHeight, windowTitle, backColor, foreColor);
	bool running=true;
    while(running){

        imgFundo = window.readFile("assets/imgFundo.png");
        window.clearWindow(backColor);

        /*********** LOAD TEXTURES ***************/
		/********** READ USER INPUTS... **********/
		window.updateInputs();
		if(window.quitRequested)
			running=false;

		/********* DRAW BACKGROUND ***************/
        window.renderTexture(imgFundo, 0, 0, 255, 0);

        if(window.keyDown(SDLKey::A))
            master.foguetao.mudarDirecao(-1);
        else if(window.keyDown(SDLKey::D))
            master.foguetao.mudarDirecao(1);
        else
            master.foguetao.mudarDirecao(0);

        if(window.keyPressed(SDLKey::SPACE)){
            master.dispararJogador();
        }

        master.updateObjects();


        if(master.foguetao.getVida()<=0){
            running=false;
        }

        master.drawObjects(window);

        window.render();
    }
    return 0;
}
